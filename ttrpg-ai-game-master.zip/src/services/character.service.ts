// Fix: Implementing the CharacterService to manage all application state.
import { Injectable, signal, computed, effect, inject } from '@angular/core';
import { GameState, MechanicTemplate, CharacterSheet, ChatMessage } from '../models/character.model';
import { GeminiService } from './gemini.service';
import { PromptBuilderService } from './prompt-builder.service';
import { RulesEngineService } from './rules-engine.service';
import { UiService } from './ui.service';
import { ValidationService } from './validation.service';

@Injectable({
  providedIn: 'root',
})
export class CharacterService {
  private geminiService = inject(GeminiService);
  private promptBuilder = inject(PromptBuilderService);
  private rulesEngine = inject(RulesEngineService);
  private uiService = inject(UiService);
  private validationService = inject(ValidationService);

  // Game State
  gameState = signal<GameState>('INIT');
  
  // Character Creation State
  genre = signal<string>('');
  mechanics = signal<MechanicTemplate | null>(null);
  stats = signal<{ [key: string]: number }>({});
  backstory = signal<string>('');
  
  // Character Sheet
  character = signal<CharacterSheet | null>(null);
  hasCharacter = computed(() => this.character() !== null);
  
  // Chat State
  chatHistory = signal<ChatMessage[]>([]);
  isModelTyping = signal(false);

  constructor() {
    // When character is created, set up the game
    effect(() => {
      const char = this.character();
      const mechs = this.mechanics();
      if (char && mechs) {
        this.gameState.set('GAME_ACTIVE');
        const systemInstruction = this.promptBuilder.getSystemInstruction(char, mechs);
        this.geminiService.startChat(systemInstruction);
        this.uiService.setActiveTab('GAME');
        this.addMessageToChat({ role: 'system', content: `The adventure for ${char.name} begins...`, timestamp: new Date()});
      }
    });
  }

  reset() {
    this.gameState.set('INIT');
    this.genre.set('');
    this.mechanics.set(null);
    this.stats.set({});
    this.backstory.set('');
    this.character.set(null);
    this.chatHistory.set([]);
    this.gameState.set('GENRE_SELECT'); // Go back to the beginning
  }

  async generateMechanics(genre: string) {
    this.gameState.set('MECHANICS_GENERATION');
    this.genre.set(genre);
    try {
      const prompt = this.promptBuilder.getMechanicsPrompt(genre);
      const result = await this.geminiService.generateMechanics(prompt);
      if (this.validationService.validateMechanicTemplate(result)) {
        this.mechanics.set(result);
        this.gameState.set('STAT_ALLOCATION');
      } else {
        throw new Error('Received invalid mechanic template from API.');
      }
    } catch (error) {
      console.error('Error generating mechanics:', error);
      this.gameState.set('ERROR');
    }
  }

  setStats(stats: { [key: string]: number }) {
    this.stats.set(stats);
    this.gameState.set('BACKSTORY_INPUT');
  }

  async generateCharacter(backstory: string) {
    this.gameState.set('CHARACTER_GENERATION');
    this.backstory.set(backstory);
    const mechs = this.mechanics();
    const stats = this.stats();
    if (!mechs) {
      console.error('Cannot generate character without mechanics.');
      this.gameState.set('ERROR');
      return;
    }
    try {
      const prompt = this.promptBuilder.getCharacterPrompt(mechs, stats, backstory);
      const result = await this.geminiService.generateCharacter(prompt, mechs);
      this.character.set(result);
    } catch (error) {
      console.error('Error generating character:', error);
      this.gameState.set('ERROR');
    }
  }

  async sendChatMessage(message: string) {
    if (this.isModelTyping()) return;

    this.addMessageToChat({ role: 'user', content: message, timestamp: new Date() });
    this.isModelTyping.set(true);

    // Check for roll commands
    const rollCommand = this.rulesEngine.parseRollCommand(message);
    if (rollCommand && this.mechanics() && this.character()) {
      const result = this.rulesEngine.executeRoll(rollCommand, this.mechanics()!, this.character()!);
      this.addMessageToChat({
        role: 'system',
        content: `Rolling ${result.roll}...`,
        rollResult: result,
        timestamp: new Date()
      });

      const gameMasterPrompt = this.promptBuilder.getGameMasterPromptWithRoll(message, result);
      this.streamResponse(gameMasterPrompt);
    } else {
      this.streamResponse(message);
    }
  }

  private streamResponse(prompt: string) {
    this.addMessageToChat({ role: 'model', content: '', timestamp: new Date() }); // Add empty message bubble
    this.geminiService.sendMessageStream(
      prompt,
      (chunk) => {
        this.chatHistory.update(history => {
            const lastMessage = history[history.length-1];
            if(lastMessage.role === 'model') {
                lastMessage.content += chunk;
            }
            return [...history];
        });
      },
      () => {
        this.isModelTyping.set(false);
      },
      (err) => {
        console.error('Error during chat stream:', err);
        this.addMessageToChat({ role: 'system', content: 'Sorry, an error occurred.', timestamp: new Date()});
        this.isModelTyping.set(false);
      }
    );
  }

  private addMessageToChat(message: Omit<ChatMessage, 'timestamp'> & { timestamp?: Date }) {
    const messageWithTimestamp: ChatMessage = {
      ...message,
      timestamp: message.timestamp || new Date(),
    };
    this.chatHistory.update(history => [...history, messageWithTimestamp]);
  }
}