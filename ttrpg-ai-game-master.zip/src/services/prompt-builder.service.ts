// Fix: Implementing the PromptBuilderService to construct prompts for the Gemini API.
import { Injectable } from '@angular/core';
import { MechanicTemplate, CharacterSheet, RollResult } from '../models/character.model';

@Injectable({
  providedIn: 'root',
})
export class PromptBuilderService {

  getMechanicsPrompt(genre: string): string {
    return `
      You are a tabletop RPG designer. Create the core mechanics for a game set in a "${genre}" world.
      Your response MUST be a JSON object that adheres to the provided schema.
      
      The mechanics should include:
      - A list of 6 primary stats (e.g., Strength, Dexterity).
      - A list of 10-12 relevant skills (e.g., Athletics, Stealth).
      - A dice rolling system. It MUST be either 'D20_System' (roll a d20 + modifier) or '2D6_System' (roll 2d6 + modifier).
      - Specify the 'roll_formula' (e.g., "1d20 + stat_modifier", "2d6 + skill_points").
      - Specify the dice type string (e.g., "d20", "2d6").
      - A 'statPointPool' for a point-buy system. It should be a number between 25 and 35.

      Example for a fantasy setting:
      {
        "setting_context": "High Fantasy Adventure",
        "mechanic_template": "D20_System",
        "roll_formula": "1d20 + stat_modifier",
        "diceType": "d20",
        "statPointPool": 27,
        "stats": ["Strength", "Dexterity", "Constitution", "Intelligence", "Wisdom", "Charisma"],
        "skills": ["Acrobatics", "Arcana", "Athletics", "Deception", "Insight", "Intimidation", "Investigation", "Medicine", "Perception", "Persuasion", "Sleight of Hand", "Stealth", "Survival"]
      }
    `;
  }

  getCharacterPrompt(
    mechanics: MechanicTemplate,
    stats: { [key: string]: number },
    backstory: string
  ): string {
    return `
      You are a creative character creator for a tabletop RPG. Based on the provided game mechanics, stats, and backstory, generate a complete and compelling character sheet.
      Your response MUST be a JSON object that adheres to the provided schema.

      Game Mechanics:
      - Setting: ${mechanics.setting_context}
      - System: ${mechanics.mechanic_template}
      - Stats available: ${mechanics.stats.join(', ')}
      - Skills available: ${mechanics.skills.join(', ')}
      
      Player Input:
      - Assigned Stats: ${JSON.stringify(stats)}
      - Backstory Outline: "${backstory}"

      Your task is to:
      1.  Invent a fitting and evocative name and a creative class/role that feels organic to the backstory (e.g., not just "Fighter", but "Exiled Sentinel" or "Clockwork Tinkerer").
      2.  Expand upon the player's backstory outline, turning it into a richer, more detailed paragraph.
      3.  Determine skill points based on the assigned stats. Distribute them logically, reflecting the character's history and role. For D20, a stat of 12 might give 1 point, 14 gives 2, etc. For 2D6, skills might just equal the related stat. Make it feel balanced.
      4.  Calculate max HP based on the system. For a D20 system, this is typically 10 + Constitution modifier. For 2D6, it might be tied to a stat value directly. Set current HP to max.
      5.  Provide a starting inventory of 3-5 items that are not just generic but are relevant to the character's class and backstory. Include at least one item that has a personal, non-mechanical significance.
      6.  Ensure the final 'stats' and 'skills' in the JSON are objects mapping the name to the final numeric value.
    `;
  }

  getSystemInstruction(
    character: CharacterSheet,
    mechanics: MechanicTemplate,
  ): string {
    return `
      You are the Game Master (GM) for an immersive, narrative-driven tabletop RPG. Your goal is to create a living, breathing world for the player.

      **World & Character Context:**
      - **Setting:** ${mechanics.setting_context}.
      - **Player Character:** You are guiding ${character.name}, a ${character.class}.
      - **Character's Past:** ${character.backstory}. Remember this history and weave it into the narrative.
      - **Character's Stats:** ${JSON.stringify(character.stats)}. A high stat means they are very capable; a low stat is a weakness. Describe outcomes accordingly.

      **Your Core Directives as GM:**
      1.  **Be Proactive & Engaging:** Do not be a passive narrator. End every response by giving the player something to react to. Describe an interesting detail, have an NPC ask a question, or introduce a new sight, sound, or smell that prompts action. Never just say "What do you do?".
      2.  **Paint a Vivid Picture:** Use strong, evocative language and appeal to multiple senses (sight, sound, smell, touch). Make the world feel real and tangible.
      3.  **Maintain Continuity:** Remember previous events, locations, and NPC interactions. Your narrative must be consistent.
      4.  **Embody the World:** Roleplay as all Non-Player Characters (NPCs) with distinct personalities and motivations.
      5.  **Interpret Player Actions & Rolls:** The player will tell you what they do and provide you with the results of any dice rolls. Your job is to narrate the consequences. A success should be described with flair, and a failure should lead to interesting, not just punishing, complications.
      6.  **Pacing:** Keep your responses concise and focused, typically 1-3 paragraphs. Keep the story moving forward.
      
      You will begin by describing the character's immediate surroundings and the situation they find themselves in. Start the adventure now.
    `;
  }
  
  getGameMasterPromptWithRoll(
    playerAction: string,
    rollResult: RollResult
  ): string {
    return `
      The player's action was: "${playerAction}"
      To resolve this, they made a roll with the following result:
      - Roll details: They rolled a total of **${rollResult.total}**.
      - Outcome: **${rollResult.success ? 'Success' : 'Failure'}**.
      
      Now, narrate the outcome of this action vividly. Don't just state the result. Describe *how* they succeeded or failed.
      - If it was a success, describe the action with confidence and competence. How did their skill manifest?
      - If it was a failure, what went wrong? Describe an interesting complication or an unexpected consequence.
      
      After describing the outcome, seamlessly transition into the next story beat. End your response with a new description or question to engage the player.
    `;
  }
}